# Route Matrix

| Route | Page Exists | Nav Exists | Protected | Issues |
|---|---|---|---|---|
| `/` | Yes | Yes | No | None |
| `/login` | Yes | Yes | No | None |
| `/dashboard` | Yes | Yes | Yes | API integrations failing (500s) |
| `/products` | Yes | Yes | Yes | `GET /products` returns 500 |
| `/robots` | Yes | Yes | Yes | `GET /robots` returns 500 |
| `/orders` | Yes | Yes | Yes | Works partially |
| `/inventory` | Yes | Yes | Yes | Missing core APIs |
