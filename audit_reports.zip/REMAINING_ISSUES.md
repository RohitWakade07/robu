# Remaining Non-Blocking Technical Debt & Issues

All P0 and P1 bugs blocking system execution have been resolved. The remaining items represent minor technical debt for future enhancement:

1. **OpenAPI Client Generation**:
   - The frontend uses a manual `client.ts` wrapper around `fetch`. Generating TypeScript types directly from FastAPI's `openapi.json` will provide compile-time contract safety for newly added endpoints.
2. **Frontend Test Suite Setup**:
   - `npm run test` script is currently unconfigured in `package.json`. Adding Vitest / React Testing Library will enable UI unit testing.
3. **Database Migrations (Alembic)**:
   - Schema updates currently rely on `Base.metadata.create_all`. Adding explicit Alembic migration scripts will facilitate staging database schema migrations.
