# Authentication & Authorization Report

## Overview
Security enforcement is handled via **JWT (JSON Web Tokens)** using `python-jose` with `HS256` signing and `bcrypt` password hashing.

## Token Lifecycle Testing
1. **Login & Issue (`POST /api/v1/auth/login`)**:
   - Accepts JSON `{"email": "...", "password": "..."}`.
   - Returns `{ "access_token": "...", "refresh_token": "...", "token_type": "bearer" }`.
   - Access Token Expiry: 30 minutes.
   - Refresh Token Expiry: 7 days.
2. **Token Injection (`Authorization: Bearer <token>`)**:
   - Frontend `client.ts` automatically attaches token from `localStorage.getItem('access_token')`.
3. **Role-Based Access Control (RBAC)**:
   - Evaluated via FastAPI dependency `require_roles(UserRole.ADMINISTRATOR, ...)`.
   - Admin routes (`/users`, `POST /products`, `POST /robots`) return `HTTP 403 Forbidden` if invoked by non-admin roles.
4. **WebSocket Security**:
   - `websocket_endpoint` verifies query parameters for token decoding before opening telemetry socket stream.
