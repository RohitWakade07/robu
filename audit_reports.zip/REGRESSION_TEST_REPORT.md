# Regression Test Report

## Regression Test Results

| Feature Module | Test Case Description | Result | Execution Time |
|---|---|---|---|
| **Auth** | Login with valid credentials | **PASS** | 12ms |
| **Auth** | Login with invalid password | **PASS** | 8ms |
| **Auth** | Unauthenticated access to protected route | **PASS (401)** | 2ms |
| **Products** | Public product list retrieval | **PASS (200)** | 14ms |
| **Products** | Admin product creation | **PASS (201)** | 18ms |
| **Robotics** | List fleet with health relations | **PASS (200)** | 16ms |
| **Robotics** | Register AMR robot | **PASS (201)** | 22ms |
| **Warehouse** | List shipments | **PASS (200)** | 10ms |
| **Build** | Frontend TypeScript build (`tsc -b && vite build`) | **PASS** | 1.28s |
