# Technical Debt List

1. **Missing Backend Tests**: Heavy reliance on functional UI testing; limited coverage on business logic.
2. **Missing `session.commit()` calls**: Services write to DB but lack explicit commits, relying on dependency injection scoping which fails in background tasks or complex routers.
3. **Frontend API Client**: Does not use a strongly typed generated client (e.g., OpenAPI generator), leading to runtime contract mismatches.
4. **Error Handling**: API errors are returned as raw 500s instead of specific Pydantic or SQLAlchemy mapped HTTPExceptions.
5. **UI State Edge Cases**: Stale data caching when WebSockets lose connectivity.
