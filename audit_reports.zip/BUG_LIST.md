# Bug List

| ID | Severity | Category | Title | Location | Problem | Expected Behavior | Actual Behavior | Fix |
|---|---|---|---|---|---|---|---|---|
| BUG-001 | P1 | API | GET /products Internal Server Error | `api/v1/customer.py` | Missing `await` on DB transaction or unhandled relation | Should return public products | HTTP 500 error when called without auth | Fix ProductService DB session |
| BUG-002 | P1 | API | POST /products Internal Server Error | `api/v1/customer.py` | Transaction not committed | Should create product and return 201 | HTTP 500 | Add `commit()` |
| BUG-003 | P1 | API | POST /shipments Internal Server Error | `api/v1/warehouse.py` | DB constraints or unhandled exception | Should create shipment | HTTP 500 | Add exception handling |
| BUG-004 | P1 | API | GET /robots Internal Server Error | `api/v1/robots.py` | Relation loading error in query | Should return robots | HTTP 500 | Fix Robot ORM relationship loading |
| BUG-005 | P1 | API | POST /robots Internal Server Error | `api/v1/robots.py` | Uncommitted session in RobotCreate | Should create robot | HTTP 500 | Fix `RobotService.create_robot` |
| BUG-006 | P3 | Frontend | Broken Auth state handling | `authStore.ts` | Token refresh fails silently on certain network errors | Should log out user | Appears frozen | Handle refresh errors |
