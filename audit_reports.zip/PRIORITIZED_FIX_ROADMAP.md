# Prioritized Fix Roadmap

## Priority 0 (Critical)
1. **Fix Database Transaction Handling**: Ensure all `create_*` endpoints successfully commit to PostgreSQL/SQLite (Fix 500 errors).

## Priority 1 (High)
2. **Fix `GET /products`**: Ensure public catalog loading handles auth context safely.
3. **Fix `GET /robots`**: Fix relation loading to allow dashboards to load robot fleet.

## Priority 2 (Medium)
4. **Implement Missing Inventory APIs**: Add historical stock movement APIs.
5. **Standardize Error Responses**: Wrap database exceptions in meaningful 400/404/409 codes.

## Priority 3 (Low)
6. **Purge/Wire Dead APIs**: Hook up `/simulate` and map uploading in the UI.
