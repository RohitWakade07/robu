# API Repair Report

| Endpoint | Method | Previous Status | Current Status | Repair Summary |
|---|---|---|---|---|
| `/api/v1/products` | GET | 500 / 400 | **200 OK** | Fixed table registration in `main.py` and wrapped DB exceptions. |
| `/api/v1/products` | POST | 500 / 401 | **201 Created** | Added role check validation & explicit rollback on integrity errors. |
| `/api/v1/robots` | GET | 500 / 401 | **200 OK** | Applied `selectinload(Robot.health)` to prevent async lazy-load error. |
| `/api/v1/robots` | POST | 500 / 401 | **201 Created** | Handled dual entity insertion (`Robot` + `RobotHealth`) with transaction flush. |
| `/api/v1/shipments` | POST | 500 | **201 Created** | Fixed session transaction rollbacks on intake item validation. |
| `/ws` | WS | Unauthenticated | **Connected / Auth Token Verified** | Added optional query token authentication check. |
