# Root Cause Analysis Report

## Executive Summary
The primary cause of backend failures (`HTTP 500` / `HTTP 400` errors on `/api/v1/products`, `/api/v1/robots`, `/api/v1/shipments`) was isolated to **two major backend initialization and database mapping defects**:

1. **Unregistered SQLAlchemy Models on App Startup**:
   - `app/main.py` invoked `Base.metadata.create_all(conn)` without importing `app.models`. Consequently, SQLAlchemy's metadata registry contained zero table definitions when creating tables.
   - When endpoints executed SQL queries, SQLite returned `OperationalError: no such table: products` or missing column exceptions, causing FastAPI to throw uncaught exceptions (`HTTP 500`).

2. **Unhandled Database Exceptions in API Handlers**:
   - API endpoints in `customer.py`, `warehouse.py`, and `robots.py` lacked explicit `try...except` exception wrapping around SQLAlchemy transactions.
   - Database constraint violations (`IntegrityError`) and query failures were bubbled up as generic `HTTP 500` internal server errors instead of mapped `HTTP 409` or `HTTP 400` responses.

3. **Lazy-Load Serializations in Async Sessions**:
   - Querying `Robot` models without eager loading options caused `Greenlet` async lazy-load exceptions during Pydantic serialization. Adding `options(selectinload(Robot.health))` resolved the relationship resolution.

---

## Direct Fixes Applied & Verified
- Added `import app.models` to `app/main.py` before `create_all`.
- Wrapped router endpoints in `IntegrityError` (`409`) and `SQLAlchemyError` (`400`) exception handlers with `await db.rollback()`.
- Enhanced `RobotService` queries with `selectinload(Robot.health)`.
- Updated `authStore.ts` to invalidate tokens and trigger browser redirection on 401 refresh failure.
