# API Matrix

| Method | Endpoint | Backend Exists | Auth Required | Runtime Status | Classification |
|---|---|---|---|---|---|
| POST | `/register` | Yes | No | Working | Working |
| POST | `/login` | Yes | No | Working | Working |
| POST | `/refresh` | Yes | No | Working | Working |
| GET | `/me` | Yes | Yes | Working | Working |
| GET | `/products` | Yes | No | Broken (500) | Broken |
| POST | `/products` | Yes | Yes | Broken (500) | Broken |
| POST | `/orders` | Yes | Yes | Broken (500) | Broken |
| GET | `/orders` | Yes | Yes | Working | Working |
| GET | `/current` | Yes | Yes | Untested | Unknown |
| GET | `/robots` | Yes | Yes | Broken (500) | Broken |
| POST | `/robots` | Yes | Yes | Broken (500) | Broken |
