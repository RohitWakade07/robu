# Missing Feature List

Features present in UI but missing backend support:
- **Inventory Movements**: No explicit `GET /movements` endpoint for the stock movements page.
- **Analytics Demand**: Missing explicit endpoints for generating deep demand reports.
- **Reports Export**: No PDF/CSV export generation endpoints.
